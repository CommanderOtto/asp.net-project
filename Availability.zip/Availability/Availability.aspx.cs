﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Availability : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        List<Schedule> schedules;
        if (!Page.IsPostBack)
        {
            schedules = DBWrapper.getSchedulesForAdviser(UserManager.getId());
        }
        else
        {
            schedules = DBWrapper.getSharedInstance().schedules;
        }
        HtmlTableCell[] weekdayCells = new HtmlTableCell[] { sundayCell, mondayCell, tuesdayCell, wednesdayCell, thursdayCell, fridayCell, saturdayCell };
        foreach (Schedule schedule in schedules)
        {
            //weekdayCells.ElementAt(Constants.getDay(schedule.weekday)).InnerHtml += "<p>" + schedule.start + " - " + schedule.end + "<button class=\"btn btn-sm btn-danger pull-right\">X</button></p>";
            HtmlGenericControl p = new HtmlGenericControl();
            p.TagName = "p";
            p.InnerText = schedule.start + " - " + schedule.end;

            HtmlAnchor deleteButton = new HtmlAnchor();
            deleteButton.Attributes["class"] = "btn btn-sm btn-danger pull-right";
            deleteButton.ServerClick += new EventHandler(RemoveSchedule);
            deleteButton.InnerText = "X";
            deleteButton.ID = schedule.id.ToString();

            p.Controls.Add(deleteButton);
            if (schedule.weekday.ToLower().CompareTo("wendesday") == 0)
            {
                schedule.weekday = "wednesday";
            }
            weekdayCells.ElementAt(Constants.getDay(schedule.weekday)).Controls.Add(p);
        }
    }

    protected void RemoveSchedule(object sender, EventArgs e)
    {
        int id;
        if (int.TryParse(((HtmlAnchor)sender).ID, out id))
        {
            DBWrapper.deleteSchedule(id);
        }
        Response.Redirect(Page.ResolveClientUrl("./Availability.aspx"), true);
    }

    protected void add(object sender, EventArgs e)
    {
        List<HtmlInputCheckBox> days = new List<HtmlInputCheckBox>(new HtmlInputCheckBox[]{ day0, day1, day2, day3, day4, day5, day6});
        // Validate here
        int startH = int.Parse(startHour.Value) % 12;
        startH += String.Equals(startampm.Value, "PM") ? 12 : 0;
        TimeSpan startTime = new TimeSpan(startH, int.Parse(startMinute.Value), 0);
        int endH = int.Parse(endHour.Value);
        endH += String.Equals(endampm.Value, "PM") ? 12 : 0;
        TimeSpan endTime = new TimeSpan(endH, int.Parse(endMinute.Value), 0);
        List<Schedule> schedules = new List<Schedule>();
        bool hasDays = false;
        foreach (HtmlInputCheckBox day in days) 
        {
            if (day.Checked)
            {
                hasDays = true;
                Schedule schedule = new Schedule(-1, Constants.days[days.IndexOf(day)], startTime, endTime, UserManager.getId(), "");
                schedules.Add(schedule);
            }
        }
        if (hasDays)
        {
            DBWrapper.addSchedules(schedules);
        }
        Response.Redirect(Page.ResolveClientUrl("./Availability.aspx"), true);
    }
}