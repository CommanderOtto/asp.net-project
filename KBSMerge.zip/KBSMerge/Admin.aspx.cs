﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void SubmitMajor(object sender, EventArgs e)
    {
        //variables
        string Major = AddMajor_Form.Text;

        //use DBadmin to save data.
        DBadmin.AddMajor(Major);
        Response.Redirect("Admin.aspx");

    }

    protected void AdvisorSubmit(object sender, EventArgs e)
    {
        //variables
        string FirstName = FirstName_Form.Text;
        string LastName = FirstName_Form.Text;
        string Username = Username_Form.Text;
        string Password = "SomePassword1!";//dummy variable. We might have to remove password from here.
        int Status = 0;

        //use DBadmin to save data.
        DBadmin.AddAdvisor(FirstName, LastName, Username, Password, Status);
        Response.Redirect("Admin.aspx");

    }




    protected void ReasonSubmit(object sender, EventArgs e)
    {
        //variables
        string AppointmentReason = AppointmentReason_Form.Text;


        //use DBadmin to save data.
        DBadmin.AddAppointment(AppointmentReason);
        Response.Redirect("Admin.aspx");
    }

    protected void logoutButton_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("https://cas.iu.edu/cas/logout");
    }

}