﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
/// <summary>
/// Summary description for DBadmin
/// </summary>
public class DBadmin
{
    //variable init
    public static SqlConnection con;
    public static String cs;

    //constructor
    public DBadmin()
    {
        cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        con = new SqlConnection(cs);
    }

    //Add a Major to the Database
    public static Boolean AddMajor(string MajorName)
    {
        cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        con = new SqlConnection(cs);
        try
        {
            con.Open();


            SqlCommand cmd = new SqlCommand("KBS_INSERT_MAJOR", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@Major", SqlDbType.NVarChar, 50));
            cmd.Parameters["@Major"].Value = MajorName;

            cmd.ExecuteNonQuery();
            return true;

        }
        catch (Exception err)
        {
            err.ToString();
            return false;
        }
        finally
        {
            con.Close();

        }

    }//end of AddMajor

    //Add a Appointment Reason to the Database
    public static Boolean AddAppointment(string AppointmentReason)
    {
        cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        con = new SqlConnection(cs);
        try
        {
            con.Open();


            SqlCommand cmd = new SqlCommand("KBS_INSERT_REASON", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@Reason", SqlDbType.NVarChar, 150));
            cmd.Parameters["@Reason"].Value = AppointmentReason;

            cmd.ExecuteNonQuery();
            return true;

        }
        catch (Exception err)
        {
            err.ToString();
            return false;
        }
        finally
        {
            con.Close();

        }

    }//end of AddAppointmentReason

    //Add an Advisor to the Database
    public static Boolean AddAdvisor(string FirstName, string LastName, string Username, string Password, int Status)
    {

        //@First, @Last, @UserName, @Password, @Status, 1
        cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        con = new SqlConnection(cs);
        try
        {
            con.Open();


            SqlCommand cmd = new SqlCommand("KBS_INSERT_ADVISOR", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@First", SqlDbType.NVarChar, 50));
            cmd.Parameters["@First"].Value = FirstName;

            cmd.Parameters.Add(new SqlParameter("@Last", SqlDbType.NVarChar, 50));
            cmd.Parameters["@Last"].Value = LastName;

            cmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar, 25));
            cmd.Parameters["@UserName"].Value = Username;

            cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.NVarChar, 50));
            cmd.Parameters["@Password"].Value = Password;

            cmd.Parameters.Add(new SqlParameter("@Status", SqlDbType.Int));
            cmd.Parameters["@Status"].Value = Status;

            cmd.ExecuteNonQuery();
            return true;

        }
        catch (Exception err)
        {
            err.ToString();
            return false;
        }
        finally
        {
            con.Close();

        }

    }//end of AddAdvisor


}//end of public class DBadmin



