﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace KBS_Finished
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                result.Visible = false;
            }
            else
            {
                result.Visible = true;
                /*
                advisor.Value = "0";
                int temp = int.Parse(advisor.Value);
                GetPrevDates(temp);*/
            }

        }

        protected void SubmitMajor(object sender, EventArgs e)
        {
            //variables
            string Major = AddMajor_Form.Text;

            //use DBadmin to save data.
            AddMajor(Major);
            Response.Redirect("Admin.aspx");

        }

        //Add a Major to the Database
        public static Boolean AddMajor(string MajorName)
        {
            SqlConnection con;
            String cs;
            cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            con = new SqlConnection(cs);
            try
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("KBS_INSERT_MAJOR", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@Major", SqlDbType.NVarChar, 50));
                cmd.Parameters["@Major"].Value = MajorName;

                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }

        }//end of AddMajor

        //Add a Appointment Reason to the Database
        public static Boolean AddAppointment(string AppointmentReason)
        {
            SqlConnection con;
            String cs;
            cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            con = new SqlConnection(cs);
            try
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("KBS_INSERT_REASON", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@Reason", SqlDbType.NVarChar, 150));
                cmd.Parameters["@Reason"].Value = AppointmentReason;

                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }

        }//end of AddAppointmentReason

        //Add an Advisor to the Database
        public static Boolean AddAdvisor(string FirstName, string LastName, string Username, int Status)
        {

            //@First, @Last, @UserName, @Password, @Status, 1
            SqlConnection con;
            String cs;
            cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            con = new SqlConnection(cs);
            try
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("KBS_INSERT_ADVISOR", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@First", SqlDbType.NVarChar, 50));
                cmd.Parameters["@First"].Value = FirstName;

                cmd.Parameters.Add(new SqlParameter("@Last", SqlDbType.NVarChar, 50));
                cmd.Parameters["@Last"].Value = LastName;

                cmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar, 25));
                cmd.Parameters["@UserName"].Value = Username;

                cmd.Parameters.Add(new SqlParameter("@Status", SqlDbType.Int));
                cmd.Parameters["@Status"].Value = Status;

                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }

        }//end of AddAdvisor


        public static Boolean AddAdmin(string FirstName, string LastName, string Username)
        {
            //@First, @Last, @UserName, @Password, @Status, 1
            SqlConnection con;
            String cs;
            cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            con = new SqlConnection(cs);
            try
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("KBS_INSERT_ADMIN", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@First", SqlDbType.NVarChar, 50));
                cmd.Parameters["@First"].Value = FirstName;

                cmd.Parameters.Add(new SqlParameter("@Last", SqlDbType.NVarChar, 50));
                cmd.Parameters["@Last"].Value = LastName;

                cmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar, 50));
                cmd.Parameters["@UserName"].Value = Username;

                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }
        }//end AddAdmin

        protected void AdvisorSubmit(object sender, EventArgs e)
        {
            //variables
            string FirstName = FirstName_Form.Text;
            string LastName = LastName_Form.Text;
            string Username = Username_Form.Text;

            int Status = 0;

            //use DBadmin to save data.
            AddAdvisor(FirstName, LastName, Username, Status);
            Response.Redirect("Admin.aspx");

        }




        protected void ReasonSubmit(object sender, EventArgs e)
        {
            //variables
            string AppointmentReason = AppointmentReason_Form.Text;


            //use DBadmin to save data.
            AddAppointment(AppointmentReason);
            Response.Redirect("Admin.aspx");
        }



        protected void GetPrevDates(int advisor)
        {
            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);

            string holder = "SELECT Convert(VARCHAR(10), AvaDate, 110) AS Date, CONVERT(VARCHAR(5), AvaTime, 108)  AS Time FROM KBS_ADVISOR_TIMES WHERE AID =" + advisor + "AND Valid = 1";

            SqlCommand cmd = new SqlCommand(holder, con);


            try
            {
                con.Open();
                System.Data.DataTable results = new DataTable();
                SqlDataAdapter SqlData = new SqlDataAdapter(cmd);

                SqlData.Fill(results);
                result.DataSource = results;
                result.DataBind();
                con.Close();
                SqlData.Dispose();
            }
            catch (SqlException err)
            {
                err.ToString();
            }
            finally
            {
                con.Close();
            }
        }

        public Boolean CreateAdvisorTimes(string available, string time, int advisor)
        {
            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            try
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("KBS_INSERT_ADVISOR_TIME", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@Available", SqlDbType.Date));
                cmd.Parameters["@Available"].Value = available;

                cmd.Parameters.Add(new SqlParameter("@Time", SqlDbType.Time, 7));
                cmd.Parameters["@Time"].Value = time;

                cmd.Parameters.Add(new SqlParameter("@Advisor", SqlDbType.Int));
                cmd.Parameters["@Advisor"].Value = advisor;

                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }

        }//end of Create Advisor Times 

        protected void GetDate(object sender, EventArgs e)
        {
            string date = Hidden.Value.ToString();
            string time = Time.SelectedValue.ToString();
            DateTime dates = Convert.ToDateTime(date);
            if (dates > DateTime.Now)
            {

                int temp = int.Parse(AddAdvisorTime_Form.SelectedValue);
                Boolean truth = CreateAdvisorTimes(date, time, temp);

                GetPrevDates(temp);

            }
            else
            {
                hold.Text = "This date is unavailable";
            }

        }

        protected void Paging(object sender, GridViewPageEventArgs e)
        {
            int temp = int.Parse(advisor.Value);
            GetPrevDates(temp);
            result.PageIndex = e.NewPageIndex;
            result.DataBind();
        }

        private string ConvertSortDirectionToSql(SortDirection sortDirection)
        {
            string newSortDirection = String.Empty;

            switch (sortDirection)
            {
                case SortDirection.Ascending:
                    newSortDirection = "ASC";
                    break;

                case SortDirection.Descending:
                    newSortDirection = "DESC";
                    break;
            }

            return newSortDirection;
        }

        protected void Sort(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = result.DataSource as DataTable;

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection);

                result.DataSource = dataView;
                result.DataBind();
            }
        }


        protected void DeleteTime(object sender, GridViewDeleteEventArgs e)
        {
            GridViewRow row = (GridViewRow)result.Rows[e.RowIndex];
            string date = row.Cells[0].Text;
            string time = row.Cells[1].Text;

            Boolean truth = DeleteRow(date, time);

            int temp = int.Parse(advisor.Value);
            GetPrevDates(temp);


        }


        protected Boolean DeleteRow(string date, string time)
        {
            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete From KBS_ADVISOR_TIMES WHERE AvaDate='" + date + "' AND AvaTime ='" + time + "'", con);
                cmd.ExecuteNonQuery();
                return true;

            }
            catch (SqlException err)
            {
                err.ToString();
                return false;


            }
            finally
            {
                con.Close();
            }

        }

        protected void ViewAdvisorTimes(object sender, EventArgs e)
        {
            int SelectedAdvisor = Convert.ToInt32(AdvisorTime_Form.SelectedValue);
            advisor.Value = SelectedAdvisor.ToString();
            GetPrevDates(SelectedAdvisor);
        }

        protected void AddAdvisorTimes(object sender, EventArgs e)
        {
            advisor.Value = AddAdvisorTime_Form.SelectedValue;

        }


        protected void AdminSubmit(object sender, EventArgs e)
        {
            //variables
            string FirstName = AdminFirstName_Form.Text;
            string LastName = AdminLastName_Form.Text;
            string Username = AdminUsername_Form.Text;

            //use DBadmin to save data.
            AddAdvisor(FirstName, LastName, Username, 2);
            Response.Redirect("Admin.aspx");
        }

    }
}