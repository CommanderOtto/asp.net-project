﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
//importing asp.net libraries to handle the sql and database connections.
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Net.Mail;
using System.Net;
using System.Data;


namespace KBS_Finished
{
    public partial class AdvisorLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Submit(object sender, EventArgs e)
        {

            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);

            try
            {
                string username = txtUsername.Text;


                string selectSQL = "SELECT Count(*) FROM KBS_ADVISORS WHERE AdvUserName='" + username + "';";
                SqlCommand cmd = new SqlCommand(selectSQL, con);
                con.Open();
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    Response.AppendHeader("Refresh", "5;url=homePage.aspx");
                    Session["AdvUsername"] = txtUsername.Text;

                }
                else
                {
                    lblError.Text = "Username isn't recognized";
                }
                con.Close();
            }
            catch (Exception err)
            {
                err.ToString();


            }
            finally
            {
                con.Close();

            }

        }
    }
}