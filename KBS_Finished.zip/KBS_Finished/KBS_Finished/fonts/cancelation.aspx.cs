﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;



public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string APIDstr = Request.QueryString["id"];
        int APID = Convert.ToInt32(APIDstr);
        DeleteAppointments(APID);
    }

    public Boolean DeleteAppointments(int apid)
    {
        SqlConnection con;
        String cs;
        cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        con = new SqlConnection(cs);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("KBS_DELETE_APPOINTMENT", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@APID", SqlDbType.Int));
            cmd.Parameters["@APID"].Value = apid;

            cmd.ExecuteNonQuery();
            return true;

        }
        catch (Exception err)
        {
            err.ToString();
            return false;
        }
        finally
        {
            con.Close();

        }

    }//end of Delete Appointments

  
}