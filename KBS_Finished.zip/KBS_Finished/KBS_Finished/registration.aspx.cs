﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Net.Mail;
using System.Net;
using System.Data;

namespace KBS_Finished
{
    public partial class registration : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                confirmPage.Visible = false;
                StudentInformation.Visible = true;
                ContactInformation.Visible = false;

                string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
                SqlConnection con = new SqlConnection(cs);

                //always use try/catch for db connections

                try
                {
                    ListItem newItem = new ListItem();
                    newItem.Text = "Select Major";
                    newItem.Value = "0";
                    Major_Form.Items.Add(newItem);

                    string selectSQL = "Select MajName,MID From VW_KBS_MAJORS";
                    SqlCommand cmd = new SqlCommand(selectSQL, con);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        ListItem NewItem = new ListItem();
                        NewItem.Text = reader["MajName"].ToString();
                        NewItem.Value = reader["MID"].ToString();
                        Major_Form.Items.Add(NewItem);
                    }
                    reader.Close();
                    con.Close();
                }
                catch (Exception err)
                {
                    err.ToString();

                }
                finally
                {
                    con.Close();

                }

            }
        }

        public int GetStudentID(string username)
        {
            SqlConnection con;
            String cs;
            cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            con = new SqlConnection(cs);
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("KBS_GET_UID", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar, 50));
                cmd.Parameters["@UserName"].Value = username;

                cmd.Parameters.Add(new SqlParameter("@UID", SqlDbType.Int));
                cmd.Parameters["@UID"].Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();

                int count = (int)cmd.Parameters["@UID"].Value;
                con.Close();
                return count;


            }

            catch (Exception err)
            {
                err.ToString();
                return -1;

            }
            finally
            {
                con.Close();

            }
        }

        public Boolean MatchReasonsToAppointment(int reason, int appointment)
        {
            SqlConnection con;
            String cs;
            cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            con = new SqlConnection(cs);

            try
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("KBS_INSERT_REASON_LOOKUP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@Reason", SqlDbType.Int));
                cmd.Parameters["@Reason"].Value = reason;

                cmd.Parameters.Add(new SqlParameter("@Appointment", SqlDbType.Int));
                cmd.Parameters["@Appointment"].Value = appointment;

                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }

        }//end of Create Major

        public Boolean CreateAppointment(int AdvisorTime, int StudentID, string notes)
        {
            SqlConnection con;
            String cs;
            cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            con = new SqlConnection(cs);
            try
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("KBS_INSERT_APPOINTMENT", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@AdvisorTime", SqlDbType.Int));
                cmd.Parameters["@AdvisorTime"].Value = AdvisorTime;

                cmd.Parameters.Add(new SqlParameter("@Student", SqlDbType.Int));
                cmd.Parameters["@Student"].Value = StudentID;

                cmd.Parameters.Add(new SqlParameter("@Note", SqlDbType.NVarChar, 200));
                cmd.Parameters["@Note"].Value = notes;

                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }
        }//end of CreateAppointment



        //This is the event. When the user clicks submit, it will do the following:
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            string username = UserName_Form.Text;
            string notes = "Tester";
            int SID = GetStudentID(username);
            int ATID = Convert.ToInt32(TimeSlots_Form.SelectedValue);

            Boolean value = CreateAppointment(ATID, SID, notes);
            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            int APID = 0;
            try
            {
                string selectSQL = "Select APID FROM KBS_APPOINTMENTS WHERE ATID=" + ATID + ";";
                SqlCommand com = new SqlCommand(selectSQL, con);

                string setNonValid = "UPDATE KBS_ADVISOR_TIMES SET Valid=0 WHERE ATID=" + ATID + ";";
                SqlCommand edit = new SqlCommand(setNonValid, con);

                con.Open();
                APID = (int)com.ExecuteScalar();
                APIDHolder.Text = APID.ToString();
                APIDHolder.Visible = false;
                edit.ExecuteNonQuery();


            }
            catch (Exception err)
            {
                err.ToString();


            }
            finally
            {
                con.Close();

            }

            foreach (ListItem row in Reason_Form.Items)
            {
                if (row.Selected == true)
                {
                    int reasons = Convert.ToInt32(row.Value);
                    MatchReasonsToAppointment(reasons, APID);
                    Reasons.Text = Reasons.Text + " , " + row.Text;
                }
            }

            ContactInformation.Visible = false;
            confirmPage.Visible = true;
            FirstName.Text = FirstName_Form.Text;
            LastName.Text = LastName_Form.Text;
            Email.Text = Email_Form.Text;
            Major.Text = Major_Form.SelectedItem.Text;
            Phone.Text = Phone_Form.Text;
            IUID.Text = SUID_Form.Text;
            Advisor.Text = Advisor_Form.SelectedItem.Text;
            DateTime.Text = TimeSlots_Form.SelectedItem.Text;


        }

        protected void sendEmail(object sender, EventArgs e)
        {
            SmtpClient smtpClient = new SmtpClient();
            MailMessage mailMessage = new MailMessage();
            smtpClient.Host = "smtp.gmail.com";
            System.Net.NetworkCredential authentication = new System.Net.NetworkCredential("n431demo@gmail.com", "demon431");
            mailMessage.From = new MailAddress("n431demo@gmail.com");
            smtpClient.Port = int.Parse("587");
            smtpClient.EnableSsl = true;
            mailMessage.To.Add(new MailAddress(Email.Text));
            mailMessage.DeliveryNotificationOptions = DeliveryNotificationOptions.OnSuccess;
            mailMessage.Subject = "Appointment Confirmation";
            string url = "cancelation.aspx?id=" + APIDHolder.Text;
            string name = FirstName.Text + " " + LastName.Text;
            mailMessage.Body = string.Format("<b>Hello</b>{0}<br /><br />Your appointment has been confirmed, if you would like to cancel, click this <a href='{1}'>link</a>", name, url);
            try
            {
                lblInfo.Text = "word";
                smtpClient.Send(mailMessage);
                lblInfo.Text = "Words";

            }
            catch (Exception err)
            {
                lblInfo.Text = err.ToString();
            }
            finally
            {
                //    Response.AppendHeader("Refresh", "5;url=homePage.aspx");
            }
        }

        public Boolean CreateStudent(string FirstName, string LastName, string Email, string UserName, int Major, int Guest, string ID, string Phone)
        {
            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            try
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("KBS_INSERT_STUDENT", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@First", SqlDbType.NVarChar, 50));
                cmd.Parameters["@First"].Value = FirstName;

                cmd.Parameters.Add(new SqlParameter("@Last", SqlDbType.NVarChar, 50));
                cmd.Parameters["@Last"].Value = LastName;

                cmd.Parameters.Add(new SqlParameter("@Email", SqlDbType.NVarChar, 50));
                cmd.Parameters["@Email"].Value = Email;

                cmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar, 50));
                cmd.Parameters["@UserName"].Value = UserName;

                cmd.Parameters.Add(new SqlParameter("@Phone", SqlDbType.NVarChar, 50));
                cmd.Parameters["@Phone"].Value = Phone;

                cmd.Parameters.Add(new SqlParameter("@SMID", SqlDbType.NVarChar, 50));
                cmd.Parameters["@SMID"].Value = Major;

                cmd.Parameters.Add(new SqlParameter("@Prospective", SqlDbType.NVarChar, 50));
                cmd.Parameters["@Prospective"].Value = Guest;

                cmd.Parameters.Add(new SqlParameter("@SUID", SqlDbType.NChar, 10));
                cmd.Parameters["@SUID"].Value = ID;

                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }
        }//end of CreateStudent.

        public Boolean SecureVerifyStudent(string UserName)
        {
            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("KBS_COUNT_STUDENT", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar, 50));
                cmd.Parameters["@UserName"].Value = UserName;

                cmd.Parameters.Add(new SqlParameter("@count", SqlDbType.Int));
                cmd.Parameters["@count"].Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();

                int count = (int)cmd.Parameters["@count"].Value;
                con.Close();

                if (count == 1) //specify the exact expected number, instead of count > 0
                    return true;
                else return false;
            }
            catch (Exception err)
            {
                err.ToString();
                return false;
            }
            finally
            {
                con.Close();

            }
        }//end of SecureVerifyStudent

        protected void btnNext_Click(object sender, EventArgs e)
        {
            StudentInformation.Visible = false;
            ContactInformation.Visible = true;

            string First = FirstName_Form.Text;
            string Last = LastName_Form.Text;
            string Email = Email_Form.Text;
            string UserName = UserName_Form.Text;
            string Major = Major_Form.SelectedValue;
            int Maj = Convert.ToInt32(Major);
            string Phone = Phone_Form.Text;
            string UID = SUID_Form.Text;

            Boolean Student = SecureVerifyStudent(UserName);
            if (Student == false)
            {
                CreateStudent(First, Last, Email, UserName, Maj, 1, UID, Phone);
            }

            //Advisors
            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            try
            {
                ListItem newItem = new ListItem();
                newItem.Text = "Select Advisor";
                newItem.Value = "0";
                Advisor_Form.Items.Add(newItem);

                string selectSQL = "Select AID ,AdvFName, AdvLName From KBS_ADVISORS where AdvStatus != 2";
                SqlCommand comd = new SqlCommand(selectSQL, con);
                con.Open();
                SqlDataReader reads = comd.ExecuteReader();

                while (reads.Read())
                {
                    ListItem NewItem = new ListItem();
                    string first = reads["AdvFName"].ToString();
                    string last = reads["AdvLName"].ToString();
                    string full = first + " " + last;
                    NewItem.Text = full;
                    NewItem.Value = reads["AID"].ToString();
                    Advisor_Form.Items.Add(NewItem);
                }
                reads.Close();
                con.Close();
            }
            catch (Exception err)
            {
                err.ToString();

            }
            finally
            {
                con.Close();

            }


            try
            {
                string selectSQL = "Select RID, ReaDesc FROM VW_KBS_REASONS";
                SqlCommand com = new SqlCommand(selectSQL, con);
                con.Open();
                SqlDataReader reader = com.ExecuteReader();

                while (reader.Read())
                {
                    ListItem NewItem = new ListItem();
                    NewItem.Text = reader["ReaDesc"].ToString();
                    NewItem.Value = reader["RID"].ToString();
                    Reason_Form.Items.Add(NewItem);
                }
                reader.Close();
                con.Close();
            }
            catch (Exception err)
            {
                err.ToString();

            }
            finally
            {
                con.Close();

            }




        }


        protected void drpChange_Time(object sender, EventArgs e)
        {
            TimeSlots_Form.Items.Clear();

            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            try
            {
                ListItem newItem = new ListItem();
                newItem.Text = "Select Time";
                newItem.Value = "0";
                TimeSlots_Form.Items.Add(newItem);

                string selectSQL = "Select ATID , AvaTime, Convert(VARCHAR(10), AvaDate, 110) AS AvaDate From VW_KBS_ADVISOR_TIMES WHERE AID =" + Advisor_Form.SelectedValue;
                SqlCommand comd = new SqlCommand(selectSQL, con);
                con.Open();
                SqlDataReader reads = comd.ExecuteReader();

                while (reads.Read())
                {
                    ListItem NewItem = new ListItem();
                    string first = reads["AvaDate"].ToString();
                    string last = reads["AvaTime"].ToString();
                    last.Substring(1, 5);
                    string full = first + " " + last;
                    NewItem.Text = full;
                    NewItem.Value = reads["ATID"].ToString();
                    TimeSlots_Form.Items.Add(NewItem);
                }
                reads.Close();
                con.Close();
            }
            catch (Exception err)
            {
                err.ToString();

            }
            finally
            {
                con.Close();

            }

        }

        protected void cancel(object sender, EventArgs e)
        {
            string url = "cancelation.aspx?id=" + APIDHolder.Text;

            Response.Redirect(url);
        }

    }
}