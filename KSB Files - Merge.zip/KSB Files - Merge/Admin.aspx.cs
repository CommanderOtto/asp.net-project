﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            result.Visible = false;
        }
        else
        {
            result.Visible = true;
            /*
            advisor.Value = "0";
            int temp = int.Parse(advisor.Value);
            GetPrevDates(temp);*/
        }
        
    }

    protected void SubmitMajor(object sender, EventArgs e)
    {
        //variables
        string Major = AddMajor_Form.Text;

        //use DBadmin to save data.
        DBadmin.AddMajor(Major);
        Response.Redirect("Admin.aspx");

    }

    protected void AdvisorSubmit(object sender, EventArgs e)
    {
        //variables
        string FirstName = FirstName_Form.Text;
        string LastName = LastName_Form.Text;
        string Username = Username_Form.Text;
        string Password = "SomePassword1!";//dummy variable. We might have to remove password from here.
        int Status = 0;

        //use DBadmin to save data.
        DBadmin.AddAdvisor(FirstName, LastName, Username, Password, Status);
        Response.Redirect("Admin.aspx");

    }




    protected void ReasonSubmit(object sender, EventArgs e)
    {
        //variables
        string AppointmentReason = AppointmentReason_Form.Text;


        //use DBadmin to save data.
        DBadmin.AddAppointment(AppointmentReason);
        Response.Redirect("Admin.aspx");
    }



    protected void GetPrevDates(int advisor)
    {
        string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);

        string holder = "SELECT Convert(VARCHAR(10), AvaDate, 110) AS Date, CONVERT(VARCHAR(5), AvaTime, 108)  AS Time FROM KBS_ADVISOR_TIMES WHERE AID =" + advisor + "AND Valid = 1";

        SqlCommand cmd = new SqlCommand(holder, con);


        try
        {
            con.Open();
            System.Data.DataTable results = new DataTable();
            SqlDataAdapter SqlData = new SqlDataAdapter(cmd);

            SqlData.Fill(results);
            result.DataSource = results;
            result.DataBind();
            con.Close();
            SqlData.Dispose();
        }
        catch (SqlException err)
        {
            err.ToString();
        }
        finally
        {
            con.Close();
        }
    }

    protected void GetDate(object sender, EventArgs e)
    {
        string date = Hidden.Value.ToString();
        string time = Time.SelectedValue.ToString();
        DateTime dates = Convert.ToDateTime(date);
        if (dates > DateTime.Now)
        {
            DBoperations DB = new DBoperations();
            int temp = int.Parse(AddAdvisorTime_Form.SelectedValue);
            Boolean truth = DB.CreateAdvisorTimes(date, time, temp);

            GetPrevDates(temp);

        }
        else
        {
            hold.Text = "This date is unavailable";
        }

    }

    protected void Paging(object sender, GridViewPageEventArgs e)
    {
        int temp = int.Parse(advisor.Value);
        GetPrevDates(temp);
        result.PageIndex = e.NewPageIndex;
        result.DataBind();
    }

    private string ConvertSortDirectionToSql(SortDirection sortDirection)
    {
        string newSortDirection = String.Empty;

        switch (sortDirection)
        {
            case SortDirection.Ascending:
                newSortDirection = "ASC";
                break;

            case SortDirection.Descending:
                newSortDirection = "DESC";
                break;
        }

        return newSortDirection;
    }

    protected void Sort(object sender, GridViewSortEventArgs e)
    {
        DataTable dataTable = result.DataSource as DataTable;

        if (dataTable != null)
        {
            DataView dataView = new DataView(dataTable);
            dataView.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection);

            result.DataSource = dataView;
            result.DataBind();
        }
    }


    protected void DeleteTime(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow row = (GridViewRow)result.Rows[e.RowIndex];
        string date = row.Cells[0].Text;
        string time = row.Cells[1].Text;

        Boolean truth = DeleteRow(date, time);

        int temp = int.Parse(advisor.Value);
        GetPrevDates(temp);


    }


    protected Boolean DeleteRow(string date, string time)
    {
        string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);

        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete From KBS_ADVISOR_TIMES WHERE AvaDate='" + date + "' AND AvaTime ='" + time + "'", con);
            cmd.ExecuteNonQuery();
            return true;

        }
        catch (SqlException err)
        {
            err.ToString();
            return false;


        }
        finally
        {
            con.Close();
        }

    }

    protected void ViewAdvisorTimes(object sender, EventArgs e)
    {
        int SelectedAdvisor = Convert.ToInt32(AdvisorTime_Form.SelectedValue);
        advisor.Value = SelectedAdvisor.ToString();
        GetPrevDates(SelectedAdvisor);
    }

    protected void AddAdvisorTimes(object sender, EventArgs e)
    {
        advisor.Value = AddAdvisorTime_Form.SelectedValue;
        
    }


    protected void AdminSubmit(object sender, EventArgs e)
    {
        //variables
        string FirstName = AdminFirstName_Form.Text;
        string LastName = AdminLastName_Form.Text;
        string Username = AdminUsername_Form.Text;

        //use DBadmin to save data.
        DBadmin.AddAdmin(FirstName, LastName, Username);
        Response.Redirect("Admin.aspx");
    }
}