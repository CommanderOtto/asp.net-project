﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// included packages
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Appointments : System.Web.UI.Page
{

    string keyName = ""; 

    protected void Page_Load(object sender, EventArgs e)
    {

        if (ShowRange.Checked == true)
        {
            SingleDate.Visible = false;
            RangeDate.Visible = true;
        }
        else
        {
            SingleDate.Visible = true;
            RangeDate.Visible = false;
        }
    }


    protected void Show_MultiDate(object sender, EventArgs e)
    {
        if(ShowRange.Checked == true)
        {
            SingleDate.Visible = false;
            RangeDate.Visible = true;
        }
        else
        {
            SingleDate.Visible = true;
            RangeDate.Visible = false;
        }
    }

    protected void GoBack(object sender, EventArgs e)
    {
        Response.Redirect("AdvisorPortal.aspx");
    }

    //Database search for names. Will allow a advisor to search student by name

    protected void nameSearch_Click(object sender, EventArgs e)
    {
        {
            string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);

           // try
            //{

                //SqlCommand cmd = new SqlCommand (select * from )

            //}
        }
    }
    protected void dateSearch_Click(object sender, EventArgs e)
    {

    }
}