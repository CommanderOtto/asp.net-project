﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// Packages needed
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class KSB_Website_Files_AdvisorLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void loginClick_Click(object sender, EventArgs e)
    {
        string cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);

        try
        {
            string Uname = UserName.Text;
            string Pwd = Password.Text;
            string sql = "";

            sql = "select count(*) from KBS_Advisors where AID = '" + UserName + "' and AdvPassword = '" + Password + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            int thisCount = (int)cmd.ExecuteScalar();
            if (thisCount != 0)
            {
                lblMsg.Text = "login successflul! " + sql;

                cmd = new SqlCommand("select fname from KBS_Advisors where AID = '" + UserName + "'", con);
                string fn = (string)cmd.ExecuteScalar();

                Response.Redirect("AdvisorPortal.aspx");
                con.Close();
            }
            else lblMsg.Text = "User doesn't exist in the database. Please try again";
        }

        catch (Exception err)
        {
            lblMsg.Text = "Cannot submit information at this time";
        }

        finally
        {
            con.Close();
        }
    }



    protected void forgetPassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/forgetPassword.aspx");
    }
}