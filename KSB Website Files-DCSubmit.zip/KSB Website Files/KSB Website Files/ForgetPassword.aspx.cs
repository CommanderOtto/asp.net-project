﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Web.Configuration;

public partial class ForgetPassword : System.Web.UI.Page
{
    string cs;
    SqlConnection con;

    protected void Page_Load(object sender, EventArgs e)

    {
        cs = WebConfigurationManager.ConnectionStrings["localConnection"].ConnectionString;
        con = new SqlConnection(cs);
    }

    protected void ForgotPasswordButton_Click(object sender, EventArgs e)
    {
        /*try
        {
            string tempVar = ForgetPasswordText.Text;
            string sql = "select count(*) from KBS_Advisor where AID = '" + tempVar + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            int count = (int)cmd.ExecuteScalar();
            if (count != 0)
            {

            }

        }*/
    }
}