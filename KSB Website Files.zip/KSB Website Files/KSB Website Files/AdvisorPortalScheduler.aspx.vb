﻿
Partial Class KSB_Website_Files_AdvisorPortalScheduler
    Inherits System.Web.UI.Page

End Class
