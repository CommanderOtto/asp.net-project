﻿public class Volunteer
{
    public string FirstName { get; set; }

    public void Save(Volunteer v)
    {
        // Save logic
    }
}