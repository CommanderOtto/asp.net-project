﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Registration : System.Web.UI.Page
{

    //retrieving and saving to variables all the information in the form.
    string FirstName = "";
    string LastName = "";
    string Email = "";
    string MiddleName = "";
    string Gender = "";


    protected void Page_Load(object sender, EventArgs e)
    {
        StudentInformation.Visible = true;
        ContactInformation.Visible = false;
    }

    //This is the event. When the user clicks submit, it will do the following:
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
        //retrieving and saving to variables all the information in the form.
        FirstName = FirstName_Form.Text;
        LastName = LastName_Form.Text;
        MiddleName = MiddleName_Form.Text;
      
   
    }
    
    protected void btnNext_Click(object sender, EventArgs e)
    {
        StudentInformation.Visible = false;
        ContactInformation.Visible = true;
    }



}