﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{

    //retrieving and saving to variables all the information in the form.
    string FirstName = "";
    string LastName = "";
    string Email = "";
    string MiddleName = "";
    string Gender = "";


    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //This is the event. When the user clicks submit, it will do the following:
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
        //retrieving and saving to variables all the information in the form.
        FirstName = FirstName_Form.Text;
        LastName = LastName_Form.Text;
        MiddleName = MiddleName_Form.Text;
        Gender = Gender_Form.SelectedValue;
     
   
    }

    //second submit button after the first panel is hidden.
    protected void Button2_Click(object sender, EventArgs e)
    {
        // In your volunteer table
        // add three bit columns IsStaff, IsFaculty, and IsStudent
        // which will be 1 or 0 based on the user's selection. 

        Volunteer V = new Volunteer();
        V.FirstName = FirstName;
        SaveFormData(V);

    }

    public void SaveFormData(Volunteer v)
    {
        // Save to database

        // Call stored procedure to save
        // and pass parameter values
        // v.Save();

    }
}